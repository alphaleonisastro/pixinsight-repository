// ----------------------------------------------------------------------------
// PixInsight JavaScript Runtime API - PJSR Version 1.0
// ----------------------------------------------------------------------------
// HdrEnhancement_0.1.3.js - Released 2024-07-02T13:49:11Z
// ----------------------------------------------------------------------------
//
// Copyright (C) 2024, Lucas Mourey
// All Rights Reserved.
//
// Redistribution and use in both source and binary forms, with or without
// modification, is permitted provided that the following conditions are met:
//
// 1. All redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//
// 2. All redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// 3. Neither the names "PixInsight" and "Pleiades Astrophoto", nor the names
//    of their contributors, may be used to endorse or promote products derived
//    from this software without specific prior written permission. For written
//    permission, please contact info@pixinsight.com.
//
// 4. All products derived from this software, in any form whatsoever, must
//    reproduce the following acknowledgment in the end-user documentation
//    and/or other materials provided with the product:
//
//    "This product is based on software from the PixInsight project, developed
//    by Pleiades Astrophoto and its contributors (https://pixinsight.com/)."
//
//    Alternatively, if that is where third-party acknowledgments normally
//    appear, this acknowledgment must be reproduced in the product itself.
//
// THIS SOFTWARE IS PROVIDED BY PLEIADES ASTROPHOTO AND ITS CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL PLEIADES ASTROPHOTO OR ITS
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, BUSINESS
// INTERRUPTION; PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; AND LOSS OF USE,
// DATA OR PROFITS) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
// ----------------------------------------------------------------------------

/*
* HdrEnhancement v0.1.3
*
* This script makes it quick and easy to combine an image with HDR variants to enhance detail.

* Release Notes:
* 0.1.3     2024-07-02      Code refactoring.
* 0.1.2     2024-06-27      Moved utility functions to a separate file.
*                           Use cloneView function from Utilities instead of PixelMath.
* 0.1.1     2024-06-27      Reset function implemented.
* 0.1.0     2024-06-26      Initial release.
*
* Lucas Mourey - Alpha Leonis © 2024
*/

#feature-id    HdrEnhancement_v0.1.3 : Alpha Leonis > HDREnhancement

#feature-info  This script makes it quick and easy to combine an image with HDR variants to enhance detail.<br>\
               Lucas Mourey - Alpha Leonis Copyright (c) 2024

// Script constants
#define VERSION "0.1.3"
#define TITLE "HDREnhancement"

#define LABEL_MIN_WIDTH 135

// Script includes
#include "lib/constructors/HDRMultiscaleTransformConstructor.js"
#include "lib/constructors/PixelMathConstructor.js"
#include "lib/Utilities.js"
#include "lib/Engine.js"
#include "lib/dialogs/MainDialog.js"

// Script parameters
var hdrEnhancementParameters = {
   // Combination parameters
   originalImageAmount: 0.7,
   hdrLowAmount: 0.5,
   hdrHighAmount: 0.5,
   // HDR parameters
   hdrLowLayers: 5,
   hdrLowIterations: 1,
   hdrLowOverdrive: 0.0,
   hdrLowScalingFunction: "B3 Spline (5)",
   hdrHighLayers: 8,
   hdrHighIterations: 1,
   hdrHighOverdrive: 0.1,
   hdrHighScalingFunction: "B3 Spline (5)",
   // Output parameters
   createNewImage: true,
   keepHdrImages: false,
   outputViewId: "<Auto>",

   save: function() {
      Parameters.set("originalImageAmount", hdrEnhancementParameters.originalImageAmount);
      Parameters.set("hdrLowAmount", hdrEnhancementParameters.hdrLowAmount);
      Parameters.set("hdrHighAmount", hdrEnhancementParameters.hdrHighAmount);
      Parameters.set("hdrLowLayers", hdrEnhancementParameters.hdrLowLayers);
      Parameters.set("hdrLowIterations", hdrEnhancementParameters.hdrLowIterations);
      Parameters.set("hdrLowOverdrive", hdrEnhancementParameters.hdrLowOverdrive);
      Parameters.set("hdrLowScalingFunction", hdrEnhancementParameters.hdrLowScalingFunction);
      Parameters.set("hdrHighLayers", hdrEnhancementParameters.hdrHighLayers);
      Parameters.set("hdrHighIterations", hdrEnhancementParameters.hdrHighIterations);
      Parameters.set("hdrHighOverdrive", hdrEnhancementParameters.hdrHighOverdrive);
      Parameters.set("hdrHighScalingFunction", hdrEnhancementParameters.hdrHighScalingFunction);
      Parameters.set("createNewImage", hdrEnhancementParameters.createNewImage);
      Parameters.set("keepHdrImages", hdrEnhancementParameters.keepHdrImages);
      Parameters.set("outputViewId", hdrEnhancementParameters.outputViewId);
   },

   load: function() {
      if (Parameters.has("originalImageAmount")) {
         this.originalImageAmount = Parameters.getReal("originalImageAmount");
      }
      if (Parameters.has("hdrLowAmount")) {
         this.hdrLowAmount = Parameters.getReal("hdrLowAmount");
      }
      if (Parameters.has("hdrHighAmount")) {
         this.hdrHighAmount = Parameters.getReal("hdrHighAmount");
      }
      if (Parameters.has("hdrLowLayers")) {
         this.hdrLowLayers = Parameters.getInteger("hdrLowLayers");
      }
      if (Parameters.has("hdrLowIterations")) {
         this.hdrLowIterations = Parameters.getInteger("hdrLowIterations");
      }
      if (Parameters.has("hdrLowOverdrive")) {
         this.hdrLowOverdrive = Parameters.getReal("hdrLowOverdrive");
      }
      if (Parameters.has("hdrLowScalingFunction")) {
         this.hdrLowScalingFunction = Parameters.getString("hdrLowScalingFunction");
      }
      if (Parameters.has("hdrHighLayers")) {
         this.hdrHighLayers = Parameters.getInteger("hdrHighLayers");
      }
      if (Parameters.has("hdrHighIterations")) {
         this.hdrHighIterations = Parameters.getInteger("hdrHighIterations");
      }
      if (Parameters.has("hdrHighOverdrive")) {
         this.hdrHighOverdrive = Parameters.getReal("hdrHighOverdrive");
      }
      if (Parameters.has("hdrHighScalingFunction")) {
         this.hdrHighScalingFunction = Parameters.getString("hdrHighScalingFunction");
      }
      if (Parameters.has("createNewImage")) {
         this.createNewImage = Parameters.getBoolean("createNewImage");
      }
      if (Parameters.has("keepHdrImages")) {
         this.keepHdrImages = Parameters.getBoolean("keepHdrImages");
      }
      if (Parameters.has("outputViewId")) {
         this.outputViewId = Parameters.getString("outputViewId");
      }
   },

   reset: function() {
      this.originalImageAmount = 0.7;
      this.hdrLowAmount = 0.5;
      this.hdrHighAmount = 0.5;
      this.hdrLowLayers = 5;
      this.hdrLowIterations = 1;
      this.hdrLowOverdrive = 0.0;
      this.hdrLowScalingFunction = "B3 Spline (5)";
      this.hdrHighLayers = 8;
      this.hdrHighIterations = 1;
      this.hdrHighOverdrive = 0.1;
      this.hdrHighScalingFunction = "B3 Spline (5)";
      this.createNewImage = true;
      this.keepHdrImages = false;
      this.outputViewId = "<Auto>";
   }
};

var scalingFunctionNames = [
   "Linear Interpolation (3)",
   "B3 Spline (5)",
   "Small Scale 3 (3)",
   "Small Scale 4 (3)",
   "Small Scale 5 (3)",
   "Small Scale 6 (3)",
   "Small Scale 8 (3)",
   "Small Scale 12 (3)",
   "Small Scale 16 (3)",
   "Small Scale 24 (3)",
   "Small Scale 32 (3)",
   "Gaussian (5)",
   "Gaussian (7)",
   "Gaussian (9)",
   "Gaussian (11)"
];

//---------------------------------------------------------------------------
// Script entry point
//---------------------------------------------------------------------------
function main() {
   Console.writeln("");
   Console.writeln(TITLE + " " + VERSION);
   Console.hide();

   //=======================================
   // View context
   //=======================================
   if (Parameters.isViewTarget) {
      hdrEnhancementParameters.load();
      // applyHdrEnhancement(Parameters.targetView);
      HdrEnhancement(Parameters.targetView);
      return;
   }

   //=======================================
   // Global context
   //=======================================
   if (Parameters.isGlobalTarget) {
      hdrEnhancementParameters.load();
   }

   //=======================================
   // Direct context
   //=======================================
   let retVal = showDialog();
   if (retVal == 1) {
      let window = ImageWindow.activeWindow;
      let view = window.mainView;

      // applyHdrEnhancement(view);
      HdrEnhancement(view);
   } else {
      // Dialog was canceled
   }
}

main();
