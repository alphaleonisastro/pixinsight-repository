// ----------------------------------------------------------------------------
// PixInsight JavaScript Runtime API - PJSR Version 1.0
// ----------------------------------------------------------------------------
// HdrEnhancement_0.1.3.js - Released 2024-06-28T19:28:53Z
// ----------------------------------------------------------------------------
//
// This file is part of HdrEnhancement Script version 0.1.2
//
// Copyright (C) 2024, Lucas Mourey
// All Rights Reserved.
//
// Redistribution and use in both source and binary forms, with or without
// modification, is permitted provided that the following conditions are met:
//
// 1. All redistributions of source code must retain the above copyright
//    notice, this list of conditions and the following disclaimer.
//
// 2. All redistributions in binary form must reproduce the above copyright
//    notice, this list of conditions and the following disclaimer in the
//    documentation and/or other materials provided with the distribution.
//
// 3. Neither the names "PixInsight" and "Pleiades Astrophoto", nor the names
//    of their contributors, may be used to endorse or promote products derived
//    from this software without specific prior written permission. For written
//    permission, please contact info@pixinsight.com.
//
// 4. All products derived from this software, in any form whatsoever, must
//    reproduce the following acknowledgment in the end-user documentation
//    and/or other materials provided with the product:
//
//    "This product is based on software from the PixInsight project, developed
//    by Pleiades Astrophoto and its contributors (https://pixinsight.com/)."
//
//    Alternatively, if that is where third-party acknowledgments normally
//    appear, this acknowledgment must be reproduced in the product itself.
//
// THIS SOFTWARE IS PROVIDED BY PLEIADES ASTROPHOTO AND ITS CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
// PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL PLEIADES ASTROPHOTO OR ITS
// CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
// EXEMPLARY OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, BUSINESS
// INTERRUPTION; PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; AND LOSS OF USE,
// DATA OR PROFITS) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
// ----------------------------------------------------------------------------

/*
* HdrEnhancement v0.1.3
*
* This script makes it quick and easy to combine an image with HDR variants to enhance detail.

* Release Notes:
* 0.1.3     2024-06-28      First signed version.
* 0.1.2     2024-06-27      Moved utility functions to a separate file.
                            Use cloneView function from Utilities instead of PixelMath.
* 0.1.1     2024-06-27      Reset function implemented.
* 0.1       2024-06-26      Initial release.
*
* Lucas Mourey - Alpha Leonis © 2024
*/

#feature-id    HdrEnhancement_v0.1.3 : Alpha Leonis > HDR Enhancement

#feature-info  This script makes it quick and easy to combine an image with HDR variants to enhance detail.<br>\
               Lucas Mourey - Alpha Leonis Copyright (c) 2024

// Script constants
#define VERSION "0.1.3"
#define TITLE "HDR Enhancement"

#define LABEL_MIN_WIDTH 135

// Script includes
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/SectionBar.jsh>
#include <pjsr/UndoFlag.jsh>

#include "lib/Utilities.js"

// Script global variables
var hdrEnhancementParameters = {
   // Combination parameters
   originalImageAmount: 0.7,
   hdrLowAmount: 0.5,
   hdrHighAmount: 0.5,
   // HDR parameters
   hdrLowLayers: 5,
   hdrLowIterations: 1,
   hdrLowOverdrive: 0.0,
   hdrLowScalingFunction: "B3 Spline (5)",
   hdrHighLayers: 8,
   hdrHighIterations: 1,
   hdrHighOverdrive: 0.1,
   hdrHighScalingFunction: "B3 Spline (5)",
   // Output parameters
   createNewImage: true,
   keepHdrImages: false,
   outputIdentifier: "<Auto>",

   save: function() {
      Parameters.set("originalImageAmount", hdrEnhancementParameters.originalImageAmount);
      Parameters.set("hdrLowAmount", hdrEnhancementParameters.hdrLowAmount);
      Parameters.set("hdrHighAmount", hdrEnhancementParameters.hdrHighAmount);
      Parameters.set("hdrLowLayers", hdrEnhancementParameters.hdrLowLayers);
      Parameters.set("hdrLowIterations", hdrEnhancementParameters.hdrLowIterations);
      Parameters.set("hdrLowOverdrive", hdrEnhancementParameters.hdrLowOverdrive);
      Parameters.set("hdrLowScalingFunction", hdrEnhancementParameters.hdrLowScalingFunction);
      Parameters.set("hdrHighLayers", hdrEnhancementParameters.hdrHighLayers);
      Parameters.set("hdrHighIterations", hdrEnhancementParameters.hdrHighIterations);
      Parameters.set("hdrHighOverdrive", hdrEnhancementParameters.hdrHighOverdrive);
      Parameters.set("hdrHighScalingFunction", hdrEnhancementParameters.hdrHighScalingFunction);
      Parameters.set("createNewImage", hdrEnhancementParameters.createNewImage);
      Parameters.set("keepHdrImages", hdrEnhancementParameters.keepHdrImages);
      Parameters.set("outputIdentifier", hdrEnhancementParameters.outputIdentifier);
   },

   load: function() {
      if (Parameters.has("originalImageAmount")) {
         this.originalImageAmount = Parameters.getReal("originalImageAmount");
      }
      if (Parameters.has("hdrLowAmount")) {
         this.hdrLowAmount = Parameters.getReal("hdrLowAmount");
      }
      if (Parameters.has("hdrHighAmount")) {
         this.hdrHighAmount = Parameters.getReal("hdrHighAmount");
      }
      if (Parameters.has("hdrLowLayers")) {
         this.hdrLowLayers = Parameters.getInteger("hdrLowLayers");
      }
      if (Parameters.has("hdrLowIterations")) {
         this.hdrLowIterations = Parameters.getInteger("hdrLowIterations");
      }
      if (Parameters.has("hdrLowOverdrive")) {
         this.hdrLowOverdrive = Parameters.getReal("hdrLowOverdrive");
      }
      if (Parameters.has("hdrLowScalingFunction")) {
         this.hdrLowScalingFunction = Parameters.getString("hdrLowScalingFunction");
      }
      if (Parameters.has("hdrHighLayers")) {
         this.hdrHighLayers = Parameters.getInteger("hdrHighLayers");
      }
      if (Parameters.has("hdrHighIterations")) {
         this.hdrHighIterations = Parameters.getInteger("hdrHighIterations");
      }
      if (Parameters.has("hdrHighOverdrive")) {
         this.hdrHighOverdrive = Parameters.getReal("hdrHighOverdrive");
      }
      if (Parameters.has("hdrHighScalingFunction")) {
         this.hdrHighScalingFunction = Parameters.getString("hdrHighScalingFunction");
      }
      if (Parameters.has("createNewImage")) {
         this.createNewImage = Parameters.getBoolean("createNewImage");
      }
      if (Parameters.has("keepHdrImages")) {
         this.keepHdrImages = Parameters.getBoolean("keepHdrImages");
      }
      if (Parameters.has("outputIdentifier")) {
         this.outputIdentifier = Parameters.getString("outputIdentifier");
      }
   },

   default: function() {
      this.originalImageAmount = 0.7;
      this.hdrLowAmount = 0.5;
      this.hdrHighAmount = 0.5;
      this.hdrLowLayers = 5;
      this.hdrLowIterations = 1;
      this.hdrLowOverdrive = 0.0;
      this.hdrLowScalingFunction = "B3 Spline (5)";
      this.hdrHighLayers = 8;
      this.hdrHighIterations = 1;
      this.hdrHighOverdrive = 0.1;
      this.hdrHighScalingFunction = "B3 Spline (5)";
      this.createNewImage = true;
      this.keepHdrImages = false;
      this.outputIdentifier = "<Auto>";
   }
};

var scalingFunctions = [
   "Linear Interpolation (3)",
   "B3 Spline (5)",
   "Small Scale 3 (3)",
   "Small Scale 4 (3)",
   "Small Scale 5 (3)",
   "Small Scale 6 (3)",
   "Small Scale 8 (3)",
   "Small Scale 12 (3)",
   "Small Scale 16 (3)",
   "Small Scale 24 (3)",
   "Small Scale 32 (3)",
   "Gaussian (5)",
   "Gaussian (7)",
   "Gaussian (9)",
   "Gaussian (11)"
];

// Script functions

/**
 * Applies HDR enhancement to a view.
 * 
 * @param {View} view The view to apply the HDR enhancement to.
 */
function applyHdrEnhancement(view) {
   let hdrLowOutputIdentifier = view.id + "_HDR_low";
   let hdrHighOutputIdentifier = view.id + "_HDR_high";

   let enhancedOutputIdentifier;

   if (hdrEnhancementParameters.outputIdentifier != "<Auto>") {
      enhancedOutputIdentifier = hdrEnhancementParameters.outputIdentifier;
   } else {
      enhancedOutputIdentifier = view.id + "_HDR";
   }

   let hdrLowImage = cloneView(view, hdrLowOutputIdentifier);
   applyHdrMultiscaleTransform(
      hdrLowImage,
      hdrEnhancementParameters.hdrLowLayers,
      hdrEnhancementParameters.hdrLowIterations,
      hdrEnhancementParameters.hdrLowOverdrive,
      hdrEnhancementParameters.hdrLowScalingFunction,
      hdrLowOutputIdentifier
   );

   let hdrHighImage = cloneView(view, hdrHighOutputIdentifier);
   applyHdrMultiscaleTransform(
      hdrHighImage,
      hdrEnhancementParameters.hdrHighLayers,
      hdrEnhancementParameters.hdrHighIterations,
      hdrEnhancementParameters.hdrHighOverdrive,
      hdrEnhancementParameters.hdrHighScalingFunction,
      hdrHighOutputIdentifier
   );

   let hdrMixAmount = 1 - hdrEnhancementParameters.originalImageAmount;
   let hdrMixExpression = "$T*" + hdrEnhancementParameters.originalImageAmount + "+" +
      hdrLowImage.id + "*(" + hdrEnhancementParameters.hdrLowAmount + "*" + hdrMixAmount + ")+" +
      hdrHighImage.id + "*(" + hdrEnhancementParameters.hdrHighAmount + "*" + hdrMixAmount + ")";
   applyPixelMath(view, hdrMixExpression, hdrEnhancementParameters.createNewImage, enhancedOutputIdentifier);

   if (hdrEnhancementParameters.keepHdrImages == false) {
      hdrLowImage.window.forceClose();
      hdrHighImage.window.forceClose();
   }
}

/**
 * Applies a HDR multiscale transform to a view.
 * 
 * @param {View}   view            The view to apply the HDR multiscale transform to.
 * @param {number} layers          The number of layers for the HDR multiscale transform.
 * @param {number} iterations      The number of iterations for the HDR multiscale transform.
 * @param {number} overdrive       The overdrive for the HDR multiscale transform.
 * @param {string} scalingFunction The scaling function for the HDR multiscale transform.
 */
function applyHdrMultiscaleTransform(
      view,
      layers,
      iterations,
      overdrive,
      scalingFunction)
{
   var P = new HDRMultiscaleTransform;
   P.numberOfLayers = layers;
   P.numberOfIterations = iterations;
   P.overdrive = overdrive;
   P.scalingFunctionName = scalingFunction;
   P.toLightness = true;
   P.lightnessMask = true;

   P.executeOn(view);
}

/**
 * Applies a pixel math expression to a view and creates a new image with the result.
 *
 * @param {View}    view           The view to apply the pixel math expression to.
 * @param {string}  expression     The pixel math expression to apply.
 * @param {boolean} createNewImage Whether to create a new image with the result.
 * @param {string}  outputViewId   The ID of the output view.
 */
function applyPixelMath(
      view,
      expression,
      createNewImage,
      outputViewId) 
{
   var P = new PixelMath;
   P.expression = expression;
   P.createNewImage = createNewImage;
   P.showNewImage = true;
   P.newImageId = outputViewId;

   P.executeOn(view);
}

function HdrEnhancementDialog() {
   this.__base__ = Dialog;
   this.__base__();

   //---------------------------------------------------------------------------
   // Header
   //---------------------------------------------------------------------------

   // Prepare the header
   this.infoLabel = new Label(this);
   this.infoLabel.frameStyle = FrameStyle_Box;
   this.infoLabel.minWidth = 320;
   this.infoLabel.wordWrapping = true;
   this.infoLabel.useRichText = true;
   this.infoLabel.text = "<p><b>" + TITLE + " " + VERSION + "</b></p>" +
      "<p>Enhance the dynamic range of an image by combining images with lower " +
      "and higher dynamic ranges to an original image.</p>" +
      "<p>Lucas Mourey - Alpha Leonis &copy; 2024</p>";

   //---------------------------------------------------------------------------
   // Combination controls
   //---------------------------------------------------------------------------

   // Prepare the numeric control for the amount of original image to mix
   this.originalImageAmount = new NumericControl(this);
   this.originalImageAmount.label.text = "Original image amount:";
   this.originalImageAmount.toolTip = "<p>Amount of the original image to mix with the HDR images.</p>" +
      "<p>0.0: only HDR images<br>" +
      "1.0: only original image</p>" +
      "<p>Recommended value: 0.7</p>";
   this.originalImageAmount.label.minWidth = LABEL_MIN_WIDTH;
   this.originalImageAmount.precision = 2;
   this.originalImageAmount.setRange(0, 1);
   this.originalImageAmount.edit.text = hdrEnhancementParameters.originalImageAmount.toFixed(2).toString();
   this.originalImageAmount.slider.setRange(0, 100);
   this.originalImageAmount.slider.value = hdrEnhancementParameters.originalImageAmount * 100;
   this.originalImageAmount.onValueUpdated = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.originalImageAmount = Math.round(this.originalImageAmount.value * 100) / 100;
   }

   // Prepare the numeric control for the amount of HDR - low to mix
   this.lowHdrAmount = new NumericControl(this);
   this.lowHdrAmount.label.text = "HDR - low amount:";
   this.lowHdrAmount.toolTip = "<p>Amount of the HDR - low to mix with the HDR - high.</p>" +
      "<p>0.0: only HDR - high<br>" +
      "1.0: only HDR - low</p>" +
      "<p>Recommended value: 0.5</p>";
   this.lowHdrAmount.label.minWidth = LABEL_MIN_WIDTH;
   this.lowHdrAmount.precision = 2;
   this.lowHdrAmount.setRange(0, 1);
   this.lowHdrAmount.edit.text = hdrEnhancementParameters.hdrLowAmount.toFixed(2).toString();
   //this.lowHdrAmount.edit.enabled = false;
   this.lowHdrAmount.slider.setRange(0, 100);
   this.lowHdrAmount.slider.value = hdrEnhancementParameters.hdrLowAmount * 100;
   this.lowHdrAmount.onValueUpdated = () => {
      // Update the GUI controls and values
      this.highHdrAmount.value = 1 - this.lowHdrAmount.value;
      this.highHdrAmount.edit.text = format("%.2f", this.highHdrAmount.value);
      this.highHdrAmount.slider.value = 100 - this.lowHdrAmount.slider.value;
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrLowAmount = Math.round(this.lowHdrAmount.value * 100) / 100;
      hdrEnhancementParameters.hdrHighAmount = Math.round(this.highHdrAmount.value * 100) / 100;
   }

   // Prepare the numeric control for the amount of HDR - high to mix
   this.highHdrAmount = new NumericControl(this);
   this.highHdrAmount.label.text = "HDR - high amount:";
   this.highHdrAmount.toolTip = "<p>Amount of the HDR - high to mix with the HDR - low.</p>" +
      "<p>0.0: only HDR - low<br>" +
      "1.0: only HDR - high</p>" +
      "<p>Recommended value: 0.5</p>";
   this.highHdrAmount.label.minWidth = LABEL_MIN_WIDTH;
   this.highHdrAmount.precision = 2;
   this.highHdrAmount.setRange(0, 1);
   this.highHdrAmount.edit.text = hdrEnhancementParameters.hdrHighAmount.toFixed(2).toString();
   this.highHdrAmount.slider.setRange(0, 100);
   this.highHdrAmount.slider.value = hdrEnhancementParameters.hdrHighAmount * 100;
   this.highHdrAmount.onValueUpdated = () => {
      // Update the GUI controls and values
      this.lowHdrAmount.value = 1 - this.highHdrAmount.value;
      this.lowHdrAmount.edit.text = format("%.2f", this.lowHdrAmount.value);
      this.lowHdrAmount.slider.value = 100 - this.highHdrAmount.slider.value;
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrLowAmount = Math.round(this.lowHdrAmount.value * 100) / 100;
      hdrEnhancementParameters.hdrHighAmount = Math.round(this.highHdrAmount.value * 100) / 100;
   }

   // Layout the controls
   this.amountParameters = new GroupBox(this);
   this.amountParameters.title = "Combination parameters";
   this.amountParameters.sizer = new VerticalSizer;
   this.amountParameters.sizer.spacing = 5;
   this.amountParameters.sizer.margin = 5;
   this.amountParameters.sizer.add(this.originalImageAmount);
   this.amountParameters.sizer.add(this.lowHdrAmount);
   this.amountParameters.sizer.add(this.highHdrAmount);

   //---------------------------------------------------------------------------
   // HDR controls
   //---------------------------------------------------------------------------

   //=======================================
   // HDR - low parameters
   //=======================================

   // Prepare the label for the number of layer of HDR - low
   this.hdrLowLayersLabel = new Label(this);
   this.hdrLowLayersLabel.text = "Layers:";
   this.hdrLowLayersLabel.toolTip = "<p>Number of layers for the HDR - low.</p>";
   this.hdrLowLayersLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;

   // Prepare the spin box for the number of layer of HDR - low
   this.hdrLowLayersSpinBox = new SpinBox(this);
   this.hdrLowLayersSpinBox.toolTip = "<p>Number of layers for the HDR - low.</p>";
   this.hdrLowLayersSpinBox.setRange(2, 16);
   this.hdrLowLayersSpinBox.value = hdrEnhancementParameters.hdrLowLayers;
   this.hdrLowLayersSpinBox.onValueUpdated = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrLowLayers = this.hdrLowLayersSpinBox.value;
   }

   // Prepare the label for the number of iterations of HDR - low
   this.hdrLowIterationsLabel = new Label(this);
   this.hdrLowIterationsLabel.text = "Iterations:";
   this.hdrLowIterationsLabel.toolTip = "<p>Number of iterations for the HDR - low.</p>";
   this.hdrLowIterationsLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;

   // Prepare the spin box for the number of iterations of HDR - low
   this.hdrLowIterationsSpinBox = new SpinBox(this);
   this.hdrLowIterationsSpinBox.toolTip = "<p>Number of iterations for the HDR - low.</p>";
   this.hdrLowIterationsSpinBox.setRange(1, 16);
   this.hdrLowIterationsSpinBox.value = hdrEnhancementParameters.hdrLowIterations;
   this.hdrLowIterationsSpinBox.onValueUpdated = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrLowIterations = this.hdrLowIterationsSpinBox.value;
   }

   // Prepare the numeric control for the overdrive of HDR - low
   this.hdrLowOverdrive = new NumericControl(this);
   this.hdrLowOverdrive.label.text = "Overdrive:";
   this.hdrLowOverdrive.toolTip = "<p>Overdrive for the HDR - low.</p>";
   this.hdrLowOverdrive.label.minWidth = LABEL_MIN_WIDTH - 34;
   this.hdrLowOverdrive.label.textAlignment = TextAlign_Right|TextAlign_VertCenter;
   this.hdrLowOverdrive.precision = 3;
   this.hdrLowOverdrive.setRange(0, 1);
   this.hdrLowOverdrive.edit.text = hdrEnhancementParameters.hdrLowOverdrive.toFixed(3).toString();
   this.hdrLowOverdrive.slider.setRange(0, 1000);
   this.hdrLowOverdrive.slider.value = hdrEnhancementParameters.hdrLowOverdrive * 1000;
   this.hdrLowOverdrive.onValueUpdated = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrLowOverdrive = Math.round(this.hdrLowOverdrive.value * 1000) / 1000;
   }

   // Prepare the label for the HDR - low scaling function
   this.hdrLowScalingFunctionLabel = new Label(this);
   this.hdrLowScalingFunctionLabel.text = "Scaling function:";
   this.hdrLowScalingFunctionLabel.toolTip = "<p>Scaling function for the HDR - low.</p>";
   this.hdrLowScalingFunctionLabel.maxWidth = LABEL_MIN_WIDTH - 35;
   this.hdrLowScalingFunctionLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;

   // Prepare the combo box for the HDR - low scaling function
   this.hdrLowScalingFunction = new ComboBox(this);
   this.hdrLowScalingFunction.toolTip = "<p>Scaling function for the HDR - low.</p>";
   scalingFunctions.forEach((scalingFunction) => {
      this.hdrLowScalingFunction.addItem(scalingFunction);
   });
   this.hdrLowScalingFunction.currentItem = this.hdrLowScalingFunction.findItem(hdrEnhancementParameters.hdrLowScalingFunction);
   this.hdrLowScalingFunction.onItemSelected = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrLowScalingFunction = this.hdrLowScalingFunction.itemText(this.hdrLowScalingFunction.currentItem);
   }

   //=======================================
   // HDR - high parameters
   //=======================================

   // Prepare the label for the number of layer of HDR - high
   this.hdrHighLayersLabel = new Label(this);
   this.hdrHighLayersLabel.text = "Layers:";
   this.hdrHighLayersLabel.toolTip = "<p>Number of layers for the HDR - high.</p>";
   this.hdrHighLayersLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;

   // Prepare the spin box for the number of layer of HDR - high
   this.hdrHighLayersSpinBox = new SpinBox(this);
   this.hdrHighLayersSpinBox.toolTip = "<p>Number of layers for the HDR - high.</p>";
   this.hdrHighLayersSpinBox.setRange(2, 16);
   this.hdrHighLayersSpinBox.value = hdrEnhancementParameters.hdrHighLayers;
   this.hdrHighLayersSpinBox.onValueUpdated = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrHighLayers = this.hdrHighLayersSpinBox.value;
   }

   // Prepare the label for the number of iterations of HDR - high
   this.hdrHighIterationsLabel = new Label(this);
   this.hdrHighIterationsLabel.text = "Iterations:";
   this.hdrHighIterationsLabel.toolTip = "<p>Number of iterations for the HDR - high.</p>";
   this.hdrHighIterationsLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;

   // Prepare the spin box for the number of iterations of HDR - high
   this.hdrHighIterationsSpinBox = new SpinBox(this);
   this.hdrHighIterationsSpinBox.toolTip = "<p>Number of iterations for the HDR - high.</p>";
   this.hdrHighIterationsSpinBox.setRange(1, 16);
   this.hdrHighIterationsSpinBox.value = hdrEnhancementParameters.hdrHighIterations;
   this.hdrHighIterationsSpinBox.onValueUpdated = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrHighIterations = this.hdrHighIterationsSpinBox.value;
   }

   // Prepare the numeric control for the overdrive of HDR - high
   this.hdrHighOverdrive = new NumericControl(this);
   this.hdrHighOverdrive.label.text = "Overdrive:";
   this.hdrHighOverdrive.toolTip = "<p>Overdrive for the HDR - high.</p>";
   this.hdrHighOverdrive.label.minWidth = LABEL_MIN_WIDTH - 34;
   this.hdrHighOverdrive.label.textAlignment = TextAlign_Right|TextAlign_VertCenter;
   this.hdrHighOverdrive.precision = 3;
   this.hdrHighOverdrive.setRange(0, 1);
   this.hdrHighOverdrive.edit.text = hdrEnhancementParameters.hdrHighOverdrive.toFixed(3).toString();
   this.hdrHighOverdrive.slider.setRange(0, 1000);
   this.hdrHighOverdrive.slider.value = hdrEnhancementParameters.hdrHighOverdrive * 1000;
   this.hdrHighOverdrive.onValueUpdated = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrHighOverdrive = Math.round(this.hdrHighOverdrive.value * 1000) / 1000;
   }

   // Prepare the label for the HDR - high scaling function
   this.hdrHighScalingFunctionLabel = new Label(this);
   this.hdrHighScalingFunctionLabel.text = "Scaling function:";
   this.hdrHighScalingFunctionLabel.toolTip = "<p>Scaling function for the HDR - high.</p>";
   this.hdrHighScalingFunctionLabel.maxWidth = LABEL_MIN_WIDTH - 35;
   this.hdrHighScalingFunctionLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;

   // Prepare the combo box for the HDR - high scaling function
   this.hdrHighScalingFunction = new ComboBox(this);
   this.hdrHighScalingFunction.toolTip = "<p>Scaling function for the HDR - high.</p>";
   scalingFunctions.forEach((scalingFunction) => {
      this.hdrHighScalingFunction.addItem(scalingFunction);
   });
   this.hdrHighScalingFunction.currentItem = this.hdrHighScalingFunction.findItem(hdrEnhancementParameters.hdrHighScalingFunction);
   this.hdrHighScalingFunction.onItemSelected = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.hdrHighScalingFunction = this.hdrHighScalingFunction.itemText(this.hdrHighScalingFunction.currentItem);
   }

   //=======================================
   // HDR - low parameters layout
   //=======================================

   this.hdrLowLayers = new HorizontalSizer(this);
   this.hdrLowLayers.spacing = 5;
   this.hdrLowLayers.add(this.hdrLowLayersLabel);
   this.hdrLowLayers.add(this.hdrLowLayersSpinBox);

   this.hdrLowIterations = new HorizontalSizer(this);
   this.hdrLowIterations.spacing = 5;
   this.hdrLowIterations.add(this.hdrLowIterationsLabel);
   this.hdrLowIterations.add(this.hdrLowIterationsSpinBox);

   this.hdrLowFirstLine = new HorizontalSizer(this);
   this.hdrLowFirstLine.spacing = 5;
   this.hdrLowFirstLine.add(this.hdrLowLayers);
   this.hdrLowFirstLine.add(this.hdrLowIterations);

   this.HdrLowThirdLine = new HorizontalSizer(this);
   this.HdrLowThirdLine.spacing = 5;
   this.HdrLowThirdLine.add(this.hdrLowScalingFunctionLabel);
   this.HdrLowThirdLine.add(this.hdrLowScalingFunction);

   this.hdrLowParameters = new GroupBox(this);
   this.hdrLowParameters.title = "HDR - low parameters";
   this.hdrLowParameters.sizer = new VerticalSizer;
   this.hdrLowParameters.sizer.spacing = 5;
   this.hdrLowParameters.sizer.margin = 5;
   this.hdrLowParameters.sizer.add(this.hdrLowFirstLine);
   this.hdrLowParameters.sizer.add(this.hdrLowOverdrive);
   this.hdrLowParameters.sizer.add(this.HdrLowThirdLine);

   //=======================================
   // HDR - high parameters layout
   //=======================================

   this.hdrHighLayers = new HorizontalSizer(this);
   this.hdrHighLayers.spacing = 5;
   this.hdrHighLayers.add(this.hdrHighLayersLabel);
   this.hdrHighLayers.add(this.hdrHighLayersSpinBox);

   this.hdrHighIterations = new HorizontalSizer(this);
   this.hdrHighIterations.spacing = 5;
   this.hdrHighIterations.add(this.hdrHighIterationsLabel);
   this.hdrHighIterations.add(this.hdrHighIterationsSpinBox);

   this.hdrHighFirstLine = new HorizontalSizer(this);
   this.hdrHighFirstLine.spacing = 5;
   this.hdrHighFirstLine.add(this.hdrHighLayers);
   this.hdrHighFirstLine.add(this.hdrHighIterations);

   this.hdrHighThirdLine = new HorizontalSizer(this);
   this.hdrHighThirdLine.spacing = 5;
   this.hdrHighThirdLine.add(this.hdrHighScalingFunctionLabel);
   this.hdrHighThirdLine.add(this.hdrHighScalingFunction);

   this.hdrHighParameters = new GroupBox(this);
   this.hdrHighParameters.title = "HDR - high parameters";
   this.hdrHighParameters.sizer = new VerticalSizer;
   this.hdrHighParameters.sizer.spacing = 5;
   this.hdrHighParameters.sizer.margin = 5;
   this.hdrHighParameters.sizer.add(this.hdrHighFirstLine);
   this.hdrHighParameters.sizer.add(this.hdrHighOverdrive);
   this.hdrHighParameters.sizer.add(this.hdrHighThirdLine);

   //=======================================
   // HDR parameters layout
   //=======================================

   this.hdrParameters = new Control(this);
   this.hdrParameters.sizer = new VerticalSizer(this);
   this.hdrParameters.sizer.spacing = 5;
   this.hdrParameters.sizer.add(this.hdrLowParameters);
   this.hdrParameters.sizer.add(this.hdrHighParameters);   

   this.hdrParametersBar = new SectionBar(this);
   this.hdrParametersBar.setTitle("HDR parameters");
   this.hdrParameters.adjustToContents();
   this.hdrParameters.hide();
   this.hdrParametersBar.setSection(this.hdrParameters);

   //---------------------------------------------------------------------------
   // Output controls
   //---------------------------------------------------------------------------

   // Prepare the check box to create a new image with the result
   this.createNewImage = new CheckBox(this);
   this.createNewImage.text = "Create new image";
   this.createNewImage.toolTip = "<p>Create a new image with the result.</p>";
   this.createNewImage.checked = hdrEnhancementParameters.createNewImage;
   this.createNewImage.onCheck = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.createNewImage = this.createNewImage.checked;
   }

   // Prepare the check box to keep the HDR images in PixInsight GUI
   this.keepHdrImages = new CheckBox(this);
   this.keepHdrImages.text = "Keep HDR images";
   this.keepHdrImages.toolTip = "<p>Keep the HDR images in PixInsight GUI.</p>";
   this.keepHdrImages.checked = hdrEnhancementParameters.keepHdrImages;
   this.keepHdrImages.onCheck = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.keepHdrImages = this.keepHdrImages.checked;
   }

   // Prepare the label for the output identifier
   this.outputIdentifierLabel = new Label(this);
   this.outputIdentifierLabel.text = "Output identifier:";
   this.outputIdentifierLabel.toolTip = "<p>Identifier for the output image.</p>";
   this.outputIdentifierLabel.minWidth = LABEL_MIN_WIDTH;
   this.outputIdentifierLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;

   // Prepare the edit for the output identifier
   this.outputIdentifier = new Edit(this);
   this.outputIdentifier.toolTip = "<p>Identifier for the output image.</p>";
   this.outputIdentifier.text = hdrEnhancementParameters.outputIdentifier;
   this.outputIdentifier.onTextUpdated = () => {
      // Update parameters in HdrEnhancementParameters object
      hdrEnhancementParameters.outputIdentifier = this.outputIdentifier.text;
   }

   // Layout the output controls
   this.outputKeepingParameters = new HorizontalSizer(this);
   this.outputKeepingParameters.spacing = 5;
   this.outputKeepingParameters.add(this.createNewImage);
   this.outputKeepingParameters.add(this.keepHdrImages);

   this.outputIdentifierSizer = new HorizontalSizer(this);
   this.outputIdentifierSizer.spacing = 5;
   this.outputIdentifierSizer.add(this.outputIdentifierLabel);
   this.outputIdentifierSizer.add(this.outputIdentifier);

   this.outputParameters = new GroupBox(this);
   this.outputParameters.title = "Output parameters";
   this.outputParameters.sizer = new VerticalSizer;
   this.outputParameters.sizer.spacing = 5;
   this.outputParameters.sizer.margin = 5;
   this.outputParameters.sizer.add(this.outputKeepingParameters);
   this.outputParameters.sizer.add(this.outputIdentifierSizer);

   //---------------------------------------------------------------------------
   // Dialog buttons
   //---------------------------------------------------------------------------

   // Prepare the new instance button
   this.newInstanceButton = new ToolButton( this );
   this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
   this.newInstanceButton.setScaledFixedSize( 24, 24 );
   this.newInstanceButton.toolTip = "New Instance";
   this.newInstanceButton.onMousePress = () => {
      // Store the parameters
      hdrEnhancementParameters.save();
      // Create the script instance
      this.newInstance();
   }

   // Prepare the execution button
   this.execButton = new ToolButton(this);
   this.execButton.icon = this.scaledResource(":/process-interface/execute.png");
   this.execButton.setScaledFixedSize(24, 24);
   this.execButton.toolTip = "<p>Apply</p>";
   this.execButton.onMousePress = () => {
      // Create the script instance
      this.ok();
   }

   // Prepare the cancel button
   this.cancelButton = new ToolButton(this);
   this.cancelButton.icon = this.scaledResource(":/process-interface/cancel.png");
   this.cancelButton.setScaledFixedSize(24, 24);
   this.cancelButton.toolTip = "<p>Cancel</p>";
   this.cancelButton.onMousePress = () => {
      this.dialog.cancel();
   }

   // Prepare the reset button
   this.resetButton = new ToolButton(this);
   this.resetButton.icon = this.scaledResource(":/images/icons/reset.png");
   this.resetButton.setScaledFixedSize(24, 24);
   this.resetButton.toolTip = "<p>Reset</p>";
   // this.resetButton.enabled = false;
   this.resetButton.onMousePress = () => {
      hdrEnhancementParameters.default();
      this.originalImageAmount.edit.text = hdrEnhancementParameters.originalImageAmount.toFixed(2).toString();
      this.originalImageAmount.slider.value = hdrEnhancementParameters.originalImageAmount * 100;
      this.lowHdrAmount.edit.text = hdrEnhancementParameters.hdrLowAmount.toFixed(2).toString();
      this.lowHdrAmount.slider.value = hdrEnhancementParameters.hdrLowAmount * 100;
      this.highHdrAmount.edit.text = hdrEnhancementParameters.hdrHighAmount.toFixed(2).toString();
      this.highHdrAmount.slider.value = hdrEnhancementParameters.hdrHighAmount * 100;
      this.hdrLowLayersSpinBox.value = hdrEnhancementParameters.hdrLowLayers;
      this.hdrLowIterationsSpinBox.value = hdrEnhancementParameters.hdrLowIterations;
      this.hdrLowOverdrive.edit.text = hdrEnhancementParameters.hdrLowOverdrive.toFixed(3).toString();
      this.hdrLowOverdrive.slider.value = hdrEnhancementParameters.hdrLowOverdrive * 1000;
      this.hdrLowScalingFunction.currentItem = this.hdrLowScalingFunction.findItem(hdrEnhancementParameters.hdrLowScalingFunction);
      this.hdrHighLayersSpinBox.value = hdrEnhancementParameters.hdrHighLayers;
      this.hdrHighIterationsSpinBox.value = hdrEnhancementParameters.hdrHighIterations;
      this.hdrHighOverdrive.edit.text = hdrEnhancementParameters.hdrHighOverdrive.toFixed(3).toString();
      this.hdrHighOverdrive.slider.value = hdrEnhancementParameters.hdrHighOverdrive * 1000;
      this.hdrHighScalingFunction.currentItem = this.hdrHighScalingFunction.findItem(hdrEnhancementParameters.hdrHighScalingFunction);
      this.createNewImage.checked = hdrEnhancementParameters.createNewImage;
      this.keepHdrImages.checked = hdrEnhancementParameters.keepHdrImages;
      this.outputIdentifier.text = hdrEnhancementParameters.outputIdentifier;
   }

   // Layout the buttons
   this.buttonSizer = new HorizontalSizer
   this.buttonSizer.spacing = 4;
   this.buttonSizer.add(this.newInstanceButton);
   this.buttonSizer.addStretch();
   this.buttonSizer.add(this.execButton);
   this.buttonSizer.add(this.cancelButton);
   this.buttonSizer.add(this.resetButton);

   //---------------------------------------------------------------------------
   // Dialog
   //---------------------------------------------------------------------------

   // Layout the dialog
   this.sizer = new VerticalSizer(this);
   this.sizer.margin = 5;
   this.sizer.spacing = 5;
   this.sizer.add(this.infoLabel);
   this.sizer.addSpacing(5);
   this.sizer.add(this.amountParameters);
   this.sizer.addSpacing(5);
   this.sizer.add(this.hdrParametersBar);
   this.sizer.add(this.hdrParameters);
   this.sizer.addSpacing(5);
   this.sizer.add(this.outputParameters);
   this.sizer.addStretch();
   this.sizer.add(this.buttonSizer);

   // Set the dialog main properties
   this.windowTitle = TITLE + " " + VERSION + " - Alpha Leonis";
   this.minWidth = 330;
   this.maxWidth = 330;
   this.adjustToContents();
}

HdrEnhancementDialog.prototype = new Dialog;

function showDialog() {
   let dialog = new HdrEnhancementDialog();
   return dialog.execute();
}

//---------------------------------------------------------------------------
// Script entry point
//---------------------------------------------------------------------------
function main() {
   Console.writeln("");
   Console.writeln(TITLE + " " + VERSION);

   //=======================================
   // View context
   //=======================================
   if (Parameters.isViewTarget) {
      hdrEnhancementParameters.load();
      applyHdrEnhancement(Parameters.targetView);
      return;
   }
   
   //=======================================
   // Global context
   //=======================================
   if (Parameters.isGlobalTarget) {
      hdrEnhancementParameters.load();
   }

   //=======================================
   // Direct context
   //=======================================
   let retVal = showDialog();
   if (retVal == 1) {
      let window = ImageWindow.activeWindow;
      let view = window.mainView;

      applyHdrEnhancement(view);
   } else {
      // Dialog was canceled
   }
}

main();
